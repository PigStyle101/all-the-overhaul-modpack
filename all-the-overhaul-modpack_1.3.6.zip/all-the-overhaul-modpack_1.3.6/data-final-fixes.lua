--need to sort some more stuff, currently working.

--things that need to happen last happen here
require("prototypes/technology/technology")
require("prototypes/recipe/fix")
require("prototypes/item/fix")
require("prototypes/grid/adjust")
require("prototypes/entity/fu_magnet_entity")
require("prototypes/evolution/evolutiondata")
require("prototypes/sorting/sorter")
require("prototypes/entity/fix")