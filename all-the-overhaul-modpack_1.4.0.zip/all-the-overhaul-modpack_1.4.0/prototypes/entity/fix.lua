data.raw["assembling-machine"]["kr-research-server"].ingredient_count = 20
data.raw["assembling-machine"]["el_purifier_entity"].ingredient_count = 20